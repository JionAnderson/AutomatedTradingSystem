import math
import numpy as np
import torch
from Model.Critic import Critic_LSTM,Critic_Transformer,Critic_AttentionCombine,Critic_TransformerKV
from Model.Env import Env
from Model.Double_DQN_Load import Double_DQN
from Setting import arg


import pandas as pd

seed_value=1259097385086300
torch.manual_seed(seed_value)
torch.cuda.manual_seed(seed_value)

state_dim = 10
hidden_size = 64
network = Critic_AttentionCombine(state_dim=state_dim,obs15m_dim=7,obs30m_dim=7,obs60m_dim=7,hiden_size=10)
target_network=Critic_AttentionCombine(state_dim=state_dim,obs15m_dim=7,obs30m_dim=7,obs60m_dim=7,hiden_size=10)
network.load_state_dict(torch.load('ModelParam/2024-7-13/64network-TransformerNoguiadance.pth'))
target_network.load_state_dict(torch.load('ModelParam/2024-7-13/64target-network-TransformerNoguiadance.pth'))
performance=pd.DataFrame(columns=['ProfitRate','Time'])
agent = Double_DQN(network=network,target_network=target_network)

epoch = 1
for k in range(epoch):
    env = Env(data_path15m="Data/CSI300-15m.csv",
              data_path30m="Data/CSI300-30m.csv",
              data_path60m="Data/CSI300-60m.csv")
    total_timesteps = 0
    timesteps_since_eval = 0
    episode_num = 0
    episode_reward = 0
    episode_timesteps = 0
    done = 1
    while env.TimeCursor < env.DataLen-2*arg.ADayTime:

        new_data=dict()
        bar=env.Data.loc[env.TimeCursor,:]
        Assert=env.account.AllCash+env.account.getMarketValue(price=bar['close'],time=bar['time'],IV=env.HV)
        new_data['ProfitRate'] = Assert / env.account.initCash
        new_data['Time'] = bar['time']
        new_Data=pd.DataFrame(new_data,index=[0])
        performance=pd.concat([performance,new_Data],ignore_index=True,axis=0)

        if done == 1:
            if total_timesteps != 0:
                print(("Total T: %d Episode Num: %d Episode T: %d Reward: %f") % (
                total_timesteps, episode_num, episode_timesteps, episode_reward))
                if env.DataLen - env.TimeCursor < arg.ADayTime * 5:
                    break

            done = 0  # Not begain
            episode_reward = 0
            episode_timesteps = 0
            episode_num += 1

            if math.isnan(episode_reward):
                print(episode_reward)
                print(k)
                print(env.Data.loc[env.TimeCursor,'time'])

        bar = env.Data.loc[env.TimeCursor, :]

        if done == 0:
            obs = env.Observation
            obs = obs.values
            obs = obs.astype(np.float64)

            obs15m = env.Observation15m
            obs15m = obs15m.values
            obs15m = obs15m.astype(np.float64)

            obs30m = env.Observation30m
            obs30m = obs30m.values
            obs30m = obs30m.astype(np.float64)

            obs60m = env.Observation60m
            obs60m = obs60m.values
            obs60m = obs60m.astype(np.float64)


            action = agent.action(obs,
                                  obs15m=obs15m,
                                  obs30m=obs30m,
                                  obs60m=obs60m,
                                  israndom=False,ResistancePointFlag=env.ResistancePointFlag,hold_time=env.hold_time)
            #print(action)
            if env.hold_time>112 or env.Observation.loc[env.Observation.shape[0]-1,'NextDay']>3:
                action=0

            new_obs, new15m,new30m,new60m,reward, done = env.step(action)

            new_obs = new_obs.values
            new_obs = new_obs.astype(np.float64)
            new15m = new15m.values
            new15m = new15m.astype(np.float64)
            new30m = new30m.values
            new30m = new30m.astype(np.float64)
            new60m = new60m.values
            new60m = new60m.astype(np.float64)



            episode_reward += reward

            #obs = new_obs
            episode_timesteps += 1
            total_timesteps += 1
            timesteps_since_eval += 1




performance.to_csv('Performance.csv',index=False)