Model文件夹
1、Critic.py 估算Q值的神经网络
2、Double_DQN.py时DDQN的强化学习框架，用Critic.py的网络，Double_DQN_Load.py是用于加载训练好的网络结构
3、Env.py模拟市场状态，账户盈亏数据
4、Eval.py用沪深300作为测试数据测试样例
5、Train.py训练用的程序文件

Preprocess文件夹
1、BSmodel.py期权定价模型
2、DataClean.py，DataFill.py数据清洗用
3、Indicator.py计算波动率
4、SettleAccount.py账户盈亏模拟
5、TransferData.py，TransferData_KV.py数据预处理模块，将股价波动变换为对数收益率
6、TransferPeriod.py变换k线周期